
function generateClone() {
    let user = document.getElementById('cloneUser').value;
    let time = document.getElementById('expiry').value;
    if (user && time) {
        let expiryDate = new Date(Date.now() + time * 3600000);
        document.getElementById('cloneResult').innerHTML =
            "<strong>Clone for:</strong> " + user + "<br><strong>Expires at:</strong> " + expiryDate.toLocaleString();
    } else {
        alert("Please fill in all fields.");
    }
}
