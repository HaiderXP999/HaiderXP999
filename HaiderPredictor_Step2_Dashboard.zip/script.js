
function vibrateAlert() {
    if ('vibrate' in navigator) {
        navigator.vibrate([200, 100, 200]);
        alert("Vibration Alert Triggered!");
    } else {
        alert("Vibration not supported on this device.");
    }
}
