
function updatePrediction() {
    let value = document.getElementById('prediction').value;
    if (value) {
        alert("Prediction Updated to: " + value);
    } else {
        alert("Please enter a prediction value.");
    }
}

function blockUser(user) {
    alert(user + " has been blocked!");
}
