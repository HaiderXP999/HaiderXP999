
// Simple frontend validation (demo only)
console.log("Haider Predictor Script Loaded");
